﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

class Solution
{

    static void Main(String[] args)
    {
        int n = Convert.ToInt32(Console.ReadLine());
        string[] arr_temp = Console.ReadLine().Split(' ');
        int[] arr = Array.ConvertAll(arr_temp, Int32.Parse);
        reverseArray(n, arr);
    }

    static public void reverseArray(int n, int[] arr)
    {
        int right = n - 1;
        int[] tempArray = new int[n];

        for (int i = 0; i < n; i++)
        {
            tempArray[right] = arr[i];
            right--;
        }

        Console.WriteLine(string.Join(" ", tempArray));

    }

}
